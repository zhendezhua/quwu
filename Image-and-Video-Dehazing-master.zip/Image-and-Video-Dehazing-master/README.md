# Dehazing
The framework used in this code is OpenCV and the codes is based on dehazing of underwater and foggy images and videos using image 
processing.
The hazy folder consists of the hazy images in png and jpg formats.
The dehaze.py fil consits if the python code. 
It consists for three main functions , for image/video manipulation, masking and thresholds. 

